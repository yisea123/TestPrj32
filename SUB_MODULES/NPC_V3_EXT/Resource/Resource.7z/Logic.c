/**
  ******************************************************************************
  * @file    /logic.c 
  * @author  zzy
  * @version V1.0.0
  * @date    2017-3-2
  * @brief   
  * 
@verbatim  

               
@endverbatim        
  *
  ******************************************************************************
  * @attention
  *
  * COPYRIGHT 2017 CQT Quartz. Co., Ltd.
  *
  ******************************************************************************
  */
	
	#include"logic.h"


RET_STATUS Log_BreakIf(CDV_INT08U *Rbuf,CMD_ARG *arg);
RET_STATUS Log_ContinueIf(CDV_INT08U *Rbuf,CMD_ARG *arg);
RET_STATUS Log_If(CDV_INT08U *Rbuf,CMD_ARG *arg);
RET_STATUS Log_ElseIf(CDV_INT08U *Rbuf,CMD_ARG *arg);
RET_STATUS Log_Else(CDV_INT08U *Rbuf,CMD_ARG *arg);
RET_STATUS Log_EndIf(CMD_ARG *arg);
RET_STATUS Log_Loop(CDV_INT08U *Rbuf,CMD_ARG *arg);
RET_STATUS Log_EndLoop(CDV_INT08U *Rbuf,CMD_ARG *arg);

/*****************������*******/

CDV_INT08U Log_Relation(CDV_INT08U ret1,CDV_INT08U ret2,CDV_INT08U relation);
CDV_INT08U Log_Compare(CDV_INT32S value,CDV_INT08U compare,CDV_INT32S Num);
CDV_INT32U Result(CDV_INT08U* p,CDV_INT32S times);
//void Log_LoopUp(CDV_INT32U *p);
CDV_INT08U BackResultToKFC(CDV_INT08U *Rbuf,CMD_ARG *arg);

//void Log_If1(CDV_INT08U *Rbuf,CDV_INT32U *pAddr);
//void Log_Loopxu(CDV_INT32U *pAddr);
//void Log_ContinueXu(CDV_INT32U * paddr,CMD_ARG *arg);
//void Log_LoopEndXu(CDV_INT32U *p);
//void Log_LoopUp(CDV_INT32U *p);



RET_STATUS LogicScript(CDV_INT08U* Rbuf,CMD_ARG *arg){
	CDV_INT08U opt , type;
	RET_STATUS ret =OPT_SUCCESS;
	//no = Rbuf[0];           //�ű���Դ��:��Ӧ�Ľű���
	opt = Rbuf[4];      //������2	
	type = Rbuf[5];		//������3(����)
	//value = Rbuf[3]; 
	switch(opt){
		case 0x00:
			switch(type){
				case 0xed:
					ret=Log_If(Rbuf,arg);
					break;
				default:
					break;	
			}
			break;
		case 0x01:
			switch(type){
				case 0xed:
					ret=Log_ElseIf(Rbuf,arg);
					break;
				default:
					break;	
			}
			break;
		case 0x02:
			switch(type){
				case 0xed:
					ret=Log_EndIf(arg);
					break;
				default:
					break;	
			}
			break;
		case 0x03:
			switch(type){
				case 0xed:
					ret=Log_Else(Rbuf,arg);
					break;
				default:
					break;	
			}
			break;
		case 0x10:
			switch(type){
				case 0xed:
					ret=Log_Loop(Rbuf,arg);
					break;
				default:
					break;	
			}
			break;
		case 0x11:
			switch(type){
				case 0xed:
					ret=Log_EndLoop(Rbuf,arg);
					break;
				default:
					break;	
			}
			break;
		case 0x12:
			switch(type){
				case 0xed:
					//ret=Log_If(Rbuf,*WorkNo,arg);
					ret=Log_BreakIf(Rbuf,arg);
					break;
				default:
					break;	
			}
			break;	
		case 0x13:
			switch(type){
				case 0xed:
					//ret=Log_If(Rbuf,*WorkNo,arg);
					ret=Log_ContinueIf(Rbuf,arg);
					break;
				default:
					break;	
			}
			break;	
		case 0x20:
			switch(type){
				case 0xed:
					//ret=Log_If(Rbuf,*WorkNo,arg);
					ret= (RET_STATUS)BackResultToKFC(Rbuf,arg);
					break;
				default:
					break;	
			}
			break;	
		default:
			break;

	}
	return ret;

}


RET_STATUS Log_If(CDV_INT08U *Rbuf,CMD_ARG *arg){

	CDV_INT08U ExpLen=0,ResNo=0,Action=0,Jump[2]={0},Calcu[100]={0}; 
	CDV_INT16U JumpCmd=0;
	CDV_INT32S Times=0;//��ʽ���ж��ٸ����� 
//	CDV_INT32U *paddr=NULL;
	CDV_INT32U Addr=0;
	ExpLen = Rbuf[6];
	JumpCmd = CalculateForAll(Rbuf,7+ExpLen,2);
	Times = ((ExpLen-9)/10+1);
	if(Result(Rbuf+7,Times)){
		return OPT_SUCCESS;
	}
	else{
		ToWorkerCmd(arg->ptrWorker, JumpCmd);//Mem_ToScriptCmd(WorkNo,JumpCmd);
		
		while(1){
	
			Addr = ((DEBUG_SCRIPT*)(arg->ptrWorker))->cmdPos + 3;//Addr = g_run.cmdPos[WorkNo];
			
			Mem_Read(&ResNo,Addr+3,1);
			Mem_Read(&Action,Addr+8,1);
			if(ResNo == 0x08 &&((Action == 0x03)||(Action == 0x02))){
				//g_run.cmdPos[WorkNo] = *paddr;
				return OPT_SUCCESS;
			}
			Mem_Read(&ExpLen,Addr+10,1);
			Mem_Read(Jump,Addr+11+ExpLen,2);
			JumpCmd = CalculateForAll(Jump,0,2);
			Times = ((ExpLen-9)/10+1);
			
			Mem_Read(Calcu,Addr+11,ExpLen);
			if(Result(Calcu,Times)){
				
				return OPT_SUCCESS;
			}
			ToWorkerCmd(arg->ptrWorker, JumpCmd);//Mem_ToScriptCmd(WorkNo,JumpCmd);
		}
		//return OPT_FAILURE;
	}	
}

RET_STATUS Log_ElseIf(CDV_INT08U *Rbuf,CMD_ARG *arg){

	CDV_INT08U ExpLen=0; 
	CDV_INT16U JumpCmd=0;
//	CDV_INT32S Times=0;//��ʽ���ж��ٸ����� 
	ExpLen = Rbuf[6];
	JumpCmd = CalculateForAll(Rbuf,7+ExpLen,2);
//	Times = ((ExpLen-6)/7+1);
//	if(Result(Rbuf+4,Times)){
//		return OPT_SUCCESS;
//	}
//	else{
		ToWorkerCmd(arg->ptrWorker, JumpCmd);//Mem_ToScriptCmd(WorkNo,JumpCmd);
		return OPT_FAILURE;
//	}	
}

RET_STATUS Log_Else(CDV_INT08U *Rbuf,CMD_ARG *arg){

	CDV_INT16U JumpCmd=0;	
	JumpCmd = CalculateForAll(Rbuf,6,2);	
	ToWorkerCmd(arg->ptrWorker, JumpCmd);//Mem_ToScriptCmd(WorkNo,JumpCmd);
	return OPT_FAILURE;
	
}

RET_STATUS Log_EndIf(CMD_ARG *arg){
	return OPT_SUCCESS;
}


RET_STATUS Log_Loop(CDV_INT08U *Rbuf,CMD_ARG *arg){

	CDV_INT08U ExpLen=0; 
	CDV_INT16U JumpCmd=0;
	CDV_INT32S Times=0;//��ʽ���ж��ٸ����� 
	
	ExpLen = Rbuf[6];
	JumpCmd = CalculateForAll(Rbuf,7+ExpLen,2);
	Times = ((ExpLen-9)/10+1);
	if(Result(Rbuf+7,Times)){
		return OPT_SUCCESS;
	}
	else{
		ToWorkerCmd(arg->ptrWorker, JumpCmd);//Mem_ToScriptCmd(WorkNo,JumpCmd);
		return OPT_SUCCESS;
	}	

}

RET_STATUS Log_EndLoop(CDV_INT08U *Rbuf,CMD_ARG *arg){

	CDV_INT16U JumpCmd=0;	
	JumpCmd = CalculateForAll(Rbuf,6,2);	
	ToWorkerCmd(arg->ptrWorker, JumpCmd);//Mem_ToScriptCmd(WorkNo,JumpCmd);
	return OPT_FAILURE;
	

}



RET_STATUS Log_BreakIf(CDV_INT08U *Rbuf,CMD_ARG *arg){

	CDV_INT08U ExpLen=0; 
	CDV_INT16U JumpCmd=0;
	CDV_INT32S Times=0;//��ʽ���ж��ٸ����� 
	
	ExpLen = Rbuf[6];
	JumpCmd = CalculateForAll(Rbuf,7+ExpLen,2);
	Times = ((ExpLen-9)/10+1);
	if(Result(Rbuf+7,Times)){
		ToWorkerCmd(arg->ptrWorker, JumpCmd);//Mem_ToScriptCmd(WorkNo,JumpCmd);
		return OPT_SUCCESS;
	}
	else{
		
		return OPT_SUCCESS;
	}	
}

RET_STATUS Log_ContinueIf(CDV_INT08U *Rbuf,CMD_ARG *arg){

	CDV_INT08U ExpLen=0;
	CDV_INT16U JumpCmd=0;
	CDV_INT32S Times=0;//��ʽ���ж��ٸ�����
	
	ExpLen = Rbuf[6];
	JumpCmd = CalculateForAll(Rbuf,7+ExpLen,2);
	Times = ((ExpLen-9)/10+1);
	if(Result(Rbuf+7,Times)){
		ToWorkerCmd(arg->ptrWorker, JumpCmd);//Mem_ToScriptCmd(WorkNo,JumpCmd);
		return OPT_FAILURE;
	}
	else{
		return OPT_SUCCESS;
	}
}
/*
 **����:�����жϵĽ��
  *
  *
  *
  *����ֵ:1����  0������
  *warnning: 
*/
CDV_INT32U Result(CDV_INT08U* p,CDV_INT32S Times){
	CDV_INT08U compare=0,num[4]={0},relation[10]={0},resultC[10]={0};
	CDV_INT32U valueno=0;
	CDV_INT32S value=0, Num=0,i=0;
//������Ԥ�ж�
		for(i=0;i<Times;i++){
//			valueno = *p;
//			compare = *(p+1);
//			memcpy(num,p+2,4);
//			relation[i] = *(p+6);
//			value = VarGet(valueno);
//			Num = CalculateForAll(num,0,4);
//			resultC[i] = Log_Compare(value,compare,Num);
//			p = p+7;
			memcpy(&valueno,p,4);
			compare = *(p+4);
			memcpy(num,p+5,4);
			relation[i] = *(p+9);
			value = VarGet(valueno);
			Num = CalculateForAll(num,0,4);
			resultC[i] = Log_Compare(value,compare,Num);
			p = p+10;
		}
			//������֮����ж�
		for(i=0;i<(Times-1);i++){
			resultC[0]= Log_Relation(resultC[0],resultC[i+1],relation[i]);
		}
		if(resultC[0]==1)return 1;
		else return 0;

}




/*
**����:�Ƚ�����ֵ�Ĺ�ϵ�Ƿ����
  *
  *
  *
  *����ֵ:1����  0������
  *warnning: 
*/

CDV_INT08U Log_Compare(CDV_INT32S value,CDV_INT08U compare,CDV_INT32S Num){

	CDV_INT32S OtherV;
	switch(compare){
		case 0xA1:
			if(value == Num)return 1;
			break;
		case 0xA2:
			if(value > Num)return 1;
			break;
		case 0xA3:
			if(value < Num)return 1;
			break;
		case 0xA4:
			if(value >= Num)return 1;
			break;
		case 0xA5:
			if(value <= Num)return 1;
			break;
		case 0xA6:
			if(value != Num)return 1;
			break;
		case 0xB1:
			OtherV = VarGet(Num);
			if(value == OtherV)return 1;
			break;
		case 0xB2:
			OtherV = VarGet(Num);
			if(value > OtherV)return 1;
			break;
		case 0xB3:
			OtherV = VarGet(Num);
			if(value < OtherV)return 1;
			break;
		case 0xB4:
			OtherV = VarGet(Num);
			if(value >= OtherV)return 1;
			break;
		case 0xB5:
			OtherV = VarGet(Num);
			if(value <= OtherV)return 1;
			break;
		case 0xB6:
			OtherV = VarGet(Num);
			if(value != OtherV)return 1;
			break;
		case 0xf1:
			return 1;
		case 0xf2:
			return 0;
		default:
			break;

	}
	return 0;
}


/*
**����:�Ƚ�������ϵʽ  �Ĺ�ϵ�Ƿ����
  *
  *
  *
  *����ֵ:1����  0������ 2error
  *warnning: 
*/

CDV_INT08U Log_Relation(CDV_INT08U ret1,CDV_INT08U ret2,CDV_INT08U relation){

	switch(relation){
		case 0x90:
			if(ret1 && ret2)return 1;
			else return 0;			
		case 0x91:
			if(ret1 || ret2)return 1;
			else return 0;
		case 0x92:
			if((ret1&&ret2)||(!(ret1||ret2)))return 0;
			else return 1;
		default:
			return 2;
	}

}



/*
**����:���ع�ʽ�ļ�������������
  *
  *
  *
  *����ֵ:1����  0������ 2error
  *warnning: 
*/
CDV_INT08U BackResultToKFC(CDV_INT08U *Rbuf,CMD_ARG *arg){

	CDV_INT08U ExpLen=0; 
	CDV_INT32S Times=0;//��ʽ���ж��ٸ����� 
	CDV_INT08U Ret=0;
	ExpLen = Rbuf[6];
	if ( ExpLen > arg->len)
		return 2;
	Times = ((ExpLen-9)/10+1);
	Ret = Result(Rbuf+7,Times);
	
	ResRequest(arg->buf, arg->len, &Ret,1, arg);//ResParaRequest(Rbuf,6,&Ret,1, arg->uart);
	return Ret;

}


//void Log_If(CDV_INT08U ValueNo,CDV_INT32U *paddr,CDV_INT32S Max,CDV_INT32S Min,CDV_INT16U Byte,CMD_ARG *arg){
//	CDV_INT08U ResNo=0,Action=0,max[4]={0},min[4]={0},byte[2]={0},nest=0;
//	CDV_INT32S value=0;
//	value = DW_CDV_VAR(ValueNo);
//	if((value>=(int)Min && value<(int)Max)||(value==Min&&value==Max)){
//		return;
//	}
//	else{
//		//ָ��ƫ��+ Byte
//		while(1){
//			*paddr = *paddr+Byte;
//			Mem_Read(&ResNo,*paddr+3,1);
//			Mem_Read(&Action,*paddr+5,1);	
//			if(ResNo == 0x08 && Action == 0x00)nest++;
//			if((ResNo == 0x08 && Action == 0X03 && nest == 0)||(ResNo == 0x08 && Action == 0X02 && nest == 0))break;
//			if(ResNo == 0x08 && Action == 0X02 && nest > 0)nest--;
//			Mem_Read(&ValueNo,*paddr+7,1);
//			Mem_Read(min,*paddr+8,4);
//			Mem_Read(max,*paddr+12,4);
//			Mem_Read(byte,*paddr+16,2);
//			value = DW_CDV_VAR(ValueNo);
//			Min = CalculateForAll(min,0,4);
//			Max = CalculateForAll(max,0,4);
//			Byte = CalculateForAll(byte,0,2);
//			if((value>=Min && value<Max)||(value==Min&&value==Max)){
//				break;
//			}
////			else{
////				*paddr = *paddr+Byte;
////			}
//		}
//		return;
//	}
//}



//void Log_If1(CDV_INT08U *Rbuf,CDV_INT32U *pAddr){

//	CDV_INT08U ResNo=0,Action=0,ExpLen=0,LeftLen=0,nest=0,flag=0; 
//	CDV_INT32S Times=0;//��ʽ���ж��ٸ����� 
//	CDV_INT32U *p = NULL,*p1 = NULL;
//	p = pAddr;
//	while(1){
//		Mem_Read(&LeftLen,*p +2,1);
//		Mem_Read(&ResNo,*p+3,1);
//		Mem_Read(&Action,*p+5,1);
//		Mem_Read(&ExpLen,*p +7,1);
//		if(ResNo != 0x08){
//			p = p+(LeftLen+3);
//			continue;
//		}
//		if(ResNo == 0x08 && Action == 0x00&& flag == 1){
//			nest++;
//			p = p+(LeftLen+3);
//			continue;
//		}
//		if((ResNo == 0x08 && Action == 0X03 && nest == 0)
//							||(ResNo == 0x08 && Action == 0X02 && nest == 0)){
//			pAddr = p;
//			break;
//		}
//		if(ResNo == 0x08 && Action == 0X02 && nest > 0){
//			nest--;
//			p = p+(LeftLen+3);
//			continue;
//		}
//		
//		Times = ((ExpLen-6)/7+1);
//		p1 = p+8;
//		if(Result(p1,Times)){
//			pAddr = p;
//			break;
//		}
//		else{
//			flag=1;//�ڶ����ҵ�IF��ʱ����������
//			p = p+(LeftLen+3);
//			continue;
//		}
//	}
//	
//}





//void Log_ElseIf(CDV_INT32U *paddr,CMD_ARG *arg){
//	CDV_INT08U ResNo=0,Action=0,nest=0,LeftLen=0;
//	while(1){
//		Mem_Read(&LeftLen,*paddr+2,1);
//		Mem_Read(&ResNo,*paddr+3,1);
//		Mem_Read(&Action,*paddr+5,1);
//		if(ResNo == 0x08 && Action == 0x00)nest++;
//		if(ResNo == 0x08 && Action == 0x02){
//			if(nest==0)break;
//			else nest--;
//		}
//		*paddr = *paddr+LeftLen+3;
//	}
//	return;
//}

//void Log_Else(CDV_INT32U *paddr,CMD_ARG *arg){
//	CDV_INT08U ResNo=0,Action=0,nest=0,LeftLen=0;

//	while(1){
//		Mem_Read(&LeftLen,*paddr+2,1);
//		Mem_Read(&ResNo,*paddr+3,1);
//		Mem_Read(&Action,*paddr+5,1);
//		if(ResNo == 0x08 && Action == 0x00)nest++;
//		if(ResNo == 0x08 && Action == 0x02){
//			if(nest==0)break;
//			else nest--;
//		}
//		*paddr = *paddr+LeftLen+3;
//	}
//	return;
//}

//void Log_EndIf(CMD_ARG *arg){
//	return;
//}





//void Log_Break(CDV_INT32U *paddr,CMD_ARG *arg){
//	//��ָ��ָ��ѭ����ĩβ(endif)

//	CDV_INT08U ResNo=0,Action=0,LeftLen=0,nest=0;
//	while(1){
//		Mem_Read(&LeftLen,*paddr+2,1);
//		Mem_Read(&ResNo,*paddr+3,1);
//		Mem_Read(&Action,*paddr+5,1);
//		if(ResNo == 0x08 && Action == 0X10) nest++;
//		if(ResNo == 0x08 && Action == 0X11){
//			if(nest==0)break;
//			else nest--;
//		} 
//			*paddr = *paddr+LeftLen+3;
//	}
//	return;
//}

//void Log_Continue(CDV_INT32U *paddr,CMD_ARG *arg){
//	CDV_INT08U ResNo=0,Action=0,byte[2]={0},LeftLen=0,nest=0;
//	CDV_INT16U Byte=0;
//	while(1){
//		Mem_Read(&LeftLen,*paddr+2,1);
//		Mem_Read(&ResNo,*paddr+3,1);
//		Mem_Read(&Action,*paddr+5,1);
//		if(ResNo == 0x08 && Action == 0X10) nest++;
//		if(ResNo == 0x08 && Action == 0X11){
//			if(nest==0){
//				Mem_Read(byte,*paddr+16,2);
//				Byte = CalculateForAll(byte,0,2);
//				*paddr = *paddr-Byte;//����������
//				break;
//			}
//			else nest--;
//		} 
//			*paddr = *paddr+LeftLen+3;
//	}
//	return;
//}


//void Log_ContinueXu(CDV_INT32U * paddr,CMD_ARG *arg){

//	Log_LoopUp(paddr);
//	return ;
//}


////void Log_Loop(CDV_INT08U ValueNo,CDV_INT32U *paddr,CDV_INT32S Max,CDV_INT32S Min,CDV_INT16U Byte,CMD_ARG *arg){
////	CDV_INT32S value=0;
////	value = DW_CDV_VAR(ValueNo);

////	if((value<Min && value>Max)||(value==Min&&value==Max)){
////		return;
////	}
////	else{
////		//ָ��ƫ��+ Byte
////		*paddr = *paddr+Byte;
////		return;
////	}
//}
////void Log_Loop1(CDV_INT08U ValueNo,CDV_INT32U *paddr,CDV_INT32S Max,CDV_INT32S Min,CDV_INT16U Byte,CMD_ARG *arg){
////	CDV_INT08U ResNo=0,Action=0,LeftLen=0,nest=0;
////	CDV_INT32S value=0;
////	value = DW_CDV_VAR(ValueNo);
////	if((value<=(int)Min && value>(int)Max)||(value==Min&&value==Max)){
////		return;
////	}
////	Mem_Read(&LeftLen,*paddr+2,1);
////	*paddr = *paddr+LeftLen+3;
////	while(1){
////		Mem_Read(&LeftLen,*paddr+2,1);
////		Mem_Read(&ResNo,*paddr+3,1);
////		Mem_Read(&Action,*paddr+5,1);
////		if(ResNo == 0x08 && Action == 0X10) nest++;
////		if(ResNo == 0x08 && Action == 0X11){
////			if(nest==0)break;
////			else nest--;
////		} 
////			*paddr = *paddr+LeftLen+3;
////	}
////	return;

////}

//void Log_Loopxu(CDV_INT32U *pAddr){
//	CDV_INT08U ResNo=0,Action=0,ExpLen=0,LeftLen=0,nest=0; 
//	CDV_INT32S Times=0;
//	CDV_INT32U *p = NULL,*p1 = NULL;
//	p = pAddr;

//	Mem_Read(&LeftLen,*p +2,1);
//	Mem_Read(&ExpLen,*p +7,1);
//	Times = ((ExpLen-6)/7+1);
//	p1 = p+8;
//	if(Result(p1,Times)){
//		pAddr = p;
//	}
//	else{
//		p = p+LeftLen+3;
//		while(1){
//			Mem_Read(&LeftLen,*p+2,1);
//			Mem_Read(&ResNo,*p+3,1);
//			Mem_Read(&Action,*p+5,1);
//			if(ResNo == 0x08 && Action == 0X10) nest++;
//			if(ResNo == 0x08 && Action == 0X11){
//				if(nest==0){
//					pAddr = p; 					
//					break;
//				}
//				else nest--;
//			} 
//				p = p+LeftLen+3;
//		}

//	}

//}


//void Log_LoopEnd(CDV_INT08U ValueNo,CDV_INT32U *paddr,CDV_INT32S Max,CDV_INT32S Min,CDV_INT16U Byte,CMD_ARG *arg){
//	CDV_INT32S value=0;
//	value = DW_CDV_VAR(ValueNo);
//	if((value<=(int)Min && value>(int)Max)||(value==Min&&value==Max)){
//		//ָ��ƫ��- Byte
//		*paddr = *paddr-Byte;
//		return;
//	}
//	else{
//		//*paddr = *paddr-Byte;
//		return;
//	}
//}


//void Log_LoopEndXu(CDV_INT32U *p){
//	CDV_INT08U EXLeftLen=0;//��һ��ʣ���ֽ�
//	Mem_Read(&EXLeftLen,*p+1,1);
//	p = p-EXLeftLen-1;
//	Log_LoopUp(p);

//}





///*
//**����:���ϱ���
//  *EXLeftLen : ��һ��ʣ���ֽ�
//  *ResNo :��Դ��
//  *Action :����
//  *nest : �ҵ�endwhile�Ĵ���
//  *warnning: ʹ��������ܺ�����ʱ��ָ������ָ��endwhile,��Ҫʹ���߰�ָ��ָ��ǰ������һ��
//  */
//void Log_LoopUp(CDV_INT32U *p){

//	CDV_INT08U EXLeftLen=0;//��һ��ʣ���ֽ�
//	CDV_INT08U ResNo=0,Action=0,nest=0; 
//	while(1){
//		Mem_Read(&EXLeftLen,*p+1,1);
//		Mem_Read(&ResNo,*p+3,1);
//		Mem_Read(&Action,*p+5,1);
//		if(ResNo == 0x08 && Action == 0X11)nest++;
//		if(ResNo == 0x08 && Action == 0X10){
//			if(nest==0){
//				break;
//			}
//			else nest--;
//		}
//		p = p-EXLeftLen-1;
//	}
//}















