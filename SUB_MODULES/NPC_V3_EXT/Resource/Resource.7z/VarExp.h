
/**
  ******************************************************************************
  * @file    /Var.h 
  * @author  MMY
  * @version V1.0.0
  * @date    2017-9-1
  * @brief   a package of var expression function
  ******************************************************************************
  * @attention
  *
  * COPYRIGHT 2017 CQT Quartz. Co., Ltd.
  *
  ******************************************************************************
  */




#ifndef  _VAR_EXP_
#define  _VAR_EXP_


#include "cdv_include.h"    


float Arithmetic(char* exp, const short expLen);
void Test();

#endif

